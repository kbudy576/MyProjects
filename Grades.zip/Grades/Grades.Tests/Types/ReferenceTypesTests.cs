﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grades.Tests.Types
{

    [TestClass]
   public class TypesTests
    {
        [TestMethod]
        public void ValueTypesPassByValue()
        {
            int x = 51;
            IncrementNum( ref x);

            Assert.AreEqual(52, x);
        }

        private void IncrementNum(ref int number) // copy of the value the changes are available only in this method.
        { 
            number += 1;
        }

        [TestMethod]
        public void ReferenceTypesPassByValue()
        {
            GradeBook book1 = new GradeBook();
            GradeBook book2 = book1;

            GiveNameToBook(book2);
            Assert.AreEqual("A Book", book1.Name);
        }

        private void GiveNameToBook(GradeBook book)
        {
            //book = new GradeBook();
            book.Name = "A Book";
        }


        [TestMethod]
        public void StringComparison()
        {
            string name1 = "Kyle";
            string name2 = "kyle";

            bool result = string.Equals(name1, name2, System.StringComparison.InvariantCultureIgnoreCase);
            Assert.IsTrue(result);
        }



        [TestMethod]
        public void IntVarHoldValue()
        {
            int x1 = 100;
            int x2 = x1;

            x1 = 4;
            Assert.AreNotEqual(x1, x2);
            //not equal bc there is new vale in x1
        }
        [TestMethod]
        public void GradeBookVariablesHoldAReference()
        {
            GradeBook g1 = new GradeBook();
            GradeBook g2 = g1; // copying pointer g1 to g2

          //  g1 = new GradeBook();
            g1.Name = "Kyle Grade book";
            Assert.AreEqual(g1.Name, g2.Name);
        }

    }
}
